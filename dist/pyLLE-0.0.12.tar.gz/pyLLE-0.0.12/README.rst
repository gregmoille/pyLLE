pyLLE 
=================

pyLLE is a tool to solve the Lugiato Lefever Equations (LLE) in a fast and easy way. Thanks to a user-friendly front-end (and a future UI) in python and a efficient back end in Julia, solving this problem becomes easy and fast.

For a complete documentation of the package, please visit the `readthedocs page <http://pylle.readthedocs.io/en/latest/index.html>`_ or check out the `github pahe <https://github.com/gregmoille/pyLLE>`_

How to Cite us 
=================

Under Construction