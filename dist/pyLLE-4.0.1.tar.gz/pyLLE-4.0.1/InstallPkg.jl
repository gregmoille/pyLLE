using Pkg

Pkg.add("HDF5")
Pkg.update("HDF5")

Pkg.add("FFTW")
Pkg.update("FFTW")

Pkg.add("LinearAlgebra")
Pkg.update("LinearAlgebra")
